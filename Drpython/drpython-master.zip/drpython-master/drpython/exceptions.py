class InvalidOperation(Exception):
    pass


class InvalidParameter(Exception):
    pass


class OutOfBoard(Exception):
    pass


class BottomReached(Exception):
    pass


class PositionOccupied(Exception):
    pass
